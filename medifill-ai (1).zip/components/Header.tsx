
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-white border-b border-slate-200 py-4 px-8 flex items-center justify-between sticky top-0 z-50">
      <div className="flex items-center gap-3">
        <div className="bg-blue-600 w-10 h-10 rounded-lg flex items-center justify-center text-white shadow-md shadow-blue-200">
          <i className="fa-solid fa-file-medical text-xl"></i>
        </div>
        <div>
          <h1 className="font-bold text-xl text-slate-900 tracking-tight">MediFill <span className="text-blue-600">AI</span></h1>
          <p className="text-xs text-slate-500 font-medium">Precision Clinical Data Extraction</p>
        </div>
      </div>
      <div className="flex items-center gap-6 text-sm font-medium">
        <nav className="flex items-center gap-4 text-slate-600">
          <a href="#" className="hover:text-blue-600 transition-colors">Documentation</a>
          <a href="#" className="hover:text-blue-600 transition-colors">Compliance</a>
          <a href="#" className="hover:text-blue-600 transition-colors">Support</a>
        </nav>
        <div className="h-6 w-px bg-slate-200"></div>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-400">
            <i className="fa-solid fa-user"></i>
          </div>
          <span className="text-slate-700">Dr. Smith</span>
        </div>
      </div>
    </header>
  );
};

export default Header;
