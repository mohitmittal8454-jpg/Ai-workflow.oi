
import React from 'react';
import { PatientSource, FileSourceType } from '../types';

interface PatientProfileProps {
  sources: PatientSource[];
  onRemoveSource: (id: string) => void;
}

const PatientProfile: React.FC<PatientProfileProps> = ({ sources, onRemoveSource }) => {
  const getIcon = (type: FileSourceType) => {
    switch (type) {
      case FileSourceType.IMAGE: return 'fa-image text-purple-500';
      case FileSourceType.TEXT: return 'fa-file-lines text-blue-500';
      case FileSourceType.PDF: return 'fa-file-pdf text-red-500';
      case FileSourceType.CSV: return 'fa-file-csv text-green-500';
      default: return 'fa-file text-slate-400';
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-bold text-slate-800 flex items-center gap-2">
          <i className="fa-solid fa-hospital-user text-blue-600"></i>
          Patient Profile
        </h2>
        <span className="text-xs font-semibold px-2 py-1 bg-blue-100 text-blue-700 rounded-full">
          {sources.length} {sources.length === 1 ? 'Record' : 'Records'}
        </span>
      </div>

      {sources.length === 0 ? (
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-10 text-center">
          <i className="fa-solid fa-database text-slate-300 text-3xl mb-3"></i>
          <p className="text-sm text-slate-400 font-medium italic">No clinical data sources uploaded yet.</p>
        </div>
      ) : (
        <div className="grid gap-3 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
          {sources.map((source) => (
            <div key={source.id} className="bg-white border border-slate-200 rounded-xl p-3 flex items-center justify-between shadow-sm hover:shadow transition-all group">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-slate-50 flex items-center justify-center">
                  <i className={`fa-solid ${getIcon(source.type)} text-lg`}></i>
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-slate-800 truncate max-w-[150px]">{source.name}</h4>
                  <p className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">{source.type}</p>
                </div>
              </div>
              <button 
                onClick={() => onRemoveSource(source.id)}
                className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-red-500 transition-all p-2"
              >
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default PatientProfile;
