
import React from 'react';
import { FormField } from '../types';

interface FormEditorProps {
  fields: FormField[];
  onFieldChange: (id: string, value: string) => void;
  isProcessing: boolean;
}

const FormEditor: React.FC<FormEditorProps> = ({ fields, onFieldChange, isProcessing }) => {
  // Fix: Explicitly type groupedFields and handle category mapping to ensure type safety
  const groupedFields = fields.reduce((acc: Record<string, FormField[]>, field) => {
    if (!acc[field.category]) acc[field.category] = [];
    acc[field.category].push(field);
    return acc;
  }, {} as Record<string, FormField[]>);

  if (fields.length === 0 && !isProcessing) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-center p-8 bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl">
        <div className="w-20 h-20 rounded-full bg-slate-200/50 flex items-center justify-center mb-4">
          <i className="fa-solid fa-magic text-slate-400 text-3xl"></i>
        </div>
        <h3 className="text-lg font-bold text-slate-700">Digital Form Preview</h3>
        <p className="text-sm text-slate-400 max-w-xs mt-2">
          Upload patient records and a blank form, then click "Auto-Fill" to see intelligent extraction results here.
        </p>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-white border border-slate-200 rounded-2xl shadow-xl overflow-hidden">
      <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <i className="fa-solid fa-pen-to-square"></i>
          <h3 className="font-bold">Extraction Review & Edit</h3>
        </div>
        <span className="text-[10px] bg-blue-600/30 text-blue-200 px-2 py-1 rounded font-bold uppercase tracking-widest">
          Draft
        </span>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-8 custom-scrollbar">
        {isProcessing ? (
          <div className="space-y-6">
            {[1, 2, 3].map(i => (
              <div key={i} className="animate-pulse">
                <div className="h-4 w-24 bg-slate-200 rounded mb-4"></div>
                <div className="space-y-3">
                  <div className="h-10 bg-slate-100 rounded"></div>
                  <div className="h-10 bg-slate-100 rounded"></div>
                </div>
              </div>
            ))}
            <div className="flex flex-col items-center py-10">
              <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mb-4"></div>
              <p className="text-sm text-slate-500 font-medium">Gemini is analyzing documents...</p>
            </div>
          </div>
        ) : (
          /* Fix: Cast Object.entries to ensure catFields is inferred as FormField[] to fix 'Property map does not exist on type unknown' */
          (Object.entries(groupedFields) as [string, FormField[]][]).map(([category, catFields]) => (
            <div key={category} className="space-y-4">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                {category}
              </h4>
              <div className="grid gap-4">
                {catFields.map((field) => (
                  <div key={field.id} className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-700 ml-1">
                      {field.label}
                    </label>
                    {field.type === 'checkbox' ? (
                      <div className="flex items-center gap-3 p-3 bg-slate-50 border border-slate-200 rounded-lg">
                        <input 
                          type="checkbox" 
                          checked={field.value.toLowerCase() === 'true'}
                          onChange={(e) => onFieldChange(field.id, e.target.checked.toString())}
                          className="w-5 h-5 text-blue-600 rounded focus:ring-blue-500"
                        />
                        <span className="text-sm text-slate-600 font-medium">Verified / Applicable</span>
                      </div>
                    ) : (
                      <input
                        type={field.type === 'date' ? 'date' : 'text'}
                        value={field.value}
                        onChange={(e) => onFieldChange(field.id, e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
                      />
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))
        )}
      </div>

      <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
        <p className="text-[10px] text-slate-400 max-w-[200px]">
          Changes are saved temporarily to this profile session. Export to finalize.
        </p>
        <button 
          className={`flex items-center gap-2 bg-slate-900 text-white px-5 py-2 rounded-lg text-sm font-bold hover:bg-slate-800 transition-all ${fields.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
          disabled={fields.length === 0}
          onClick={() => {
            const blob = new Blob([JSON.stringify(fields, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'filled-medical-data.json';
            a.click();
          }}
        >
          <i className="fa-solid fa-download"></i>
          Export
        </button>
      </div>
    </div>
  );
};

export default FormEditor;
