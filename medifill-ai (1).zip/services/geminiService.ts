
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { PatientSource, FormField, FileSourceType } from "../types";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    // Fix: Always use new GoogleGenAI({apiKey: process.env.API_KEY}) as per guidelines
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  async extractAndMap(sources: PatientSource[], formDescription: string): Promise<FormField[]> {
    const model = 'gemini-3-pro-preview';

    // Prepare content parts
    const parts: any[] = [];
    
    // Add patient data instructions
    parts.push({
      text: `Task: Extract patient information from the provided documents and map them to a medical form.
      
      Available Patient Sources:
      ${sources.map(s => `Source (${s.name}, Type: ${s.type})`).join('\n')}
      
      Instructions:
      1. Analyze all images, clinical notes, and text provided.
      2. Detect common medical form fields (Name, DOB, SSN, Insurance Provider, Policy Number, Diagnosis, Symptoms, Medications, etc.).
      3. Map the extracted data to logical fields.
      4. Handle checkboxes as "true" or "false".
      5. Return a clean JSON array of fields.`
    });

    // Add actual source content
    for (const source of sources) {
      if (source.type === FileSourceType.IMAGE || source.type === FileSourceType.PDF) {
        parts.push({
          inlineData: {
            data: source.content.split(',')[1] || source.content,
            mimeType: source.mimeType
          }
        });
      } else {
        parts.push({
          text: `Source Content (${source.name}):\n${source.content}`
        });
      }
    }

    // Fix: Use correct generateContent parameter structure with a single contents object containing parts
    const response: GenerateContentResponse = await this.ai.models.generateContent({
      model,
      contents: { parts },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            fields: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  label: { type: Type.STRING },
                  value: { type: Type.STRING },
                  type: { type: Type.STRING, enum: ['text', 'checkbox', 'date', 'select'] },
                  category: { type: Type.STRING }
                },
                required: ['id', 'label', 'value', 'type', 'category']
              }
            }
          },
          required: ['fields']
        }
      }
    });

    try {
      // Fix: Access response.text directly (not as a method)
      const result = JSON.parse(response.text || '{"fields": []}');
      return result.fields;
    } catch (e) {
      console.error("Failed to parse Gemini response", e);
      return [];
    }
  }
}

export const geminiService = new GeminiService();
