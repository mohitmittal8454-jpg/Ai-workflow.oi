
import React, { useState, useCallback } from 'react';
import Header from './components/Header';
import FileUploader from './components/FileUploader';
import PatientProfile from './components/PatientProfile';
import FormEditor from './components/FormEditor';
import { PatientSource, FileSourceType, FormField, ProcessingState } from './types';
import { geminiService } from './services/geminiService';

const App: React.FC = () => {
  const [patientSources, setPatientSources] = useState<PatientSource[]>([]);
  const [blankForm, setBlankForm] = useState<PatientSource | null>(null);
  const [extractedFields, setExtractedFields] = useState<FormField[]>([]);
  const [processing, setProcessing] = useState<ProcessingState>({
    isProcessing: false,
    status: 'Idle',
    progress: 0
  });

  const handlePatientFile = async (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      const type = file.type.includes('image') ? FileSourceType.IMAGE : 
                   file.type.includes('pdf') ? FileSourceType.PDF : 
                   file.type.includes('csv') ? FileSourceType.CSV : FileSourceType.TEXT;
      
      const newSource: PatientSource = {
        id: Math.random().toString(36).substr(2, 9),
        name: file.name,
        type,
        content: result,
        mimeType: file.type
      };
      
      setPatientSources(prev => [...prev, newSource]);
    };

    if (file.type.includes('text') || file.type.includes('csv')) {
      reader.readAsText(file);
    } else {
      reader.readAsDataURL(file);
    }
  };

  const handleBlankForm = async (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      setBlankForm({
        id: 'blank-form',
        name: file.name,
        type: FileSourceType.PDF,
        content: result,
        mimeType: file.type
      });
    };
    reader.readAsDataURL(file);
  };

  const removeSource = (id: string) => {
    setPatientSources(prev => prev.filter(s => s.id !== id));
  };

  const runAutoFill = async () => {
    if (patientSources.length === 0 || !blankForm) {
      alert("Please upload at least one patient record and a blank form.");
      return;
    }

    setProcessing({ isProcessing: true, status: 'Analyzing clinical data...', progress: 30 });
    
    try {
      const fields = await geminiService.extractAndMap(
        [...patientSources, blankForm], 
        "Extract information from patient documents and map to fields suggested by the form."
      );
      setExtractedFields(fields);
      setProcessing({ isProcessing: false, status: 'Complete', progress: 100 });
    } catch (err) {
      console.error(err);
      alert("Extraction failed. Please check your API key or data sources.");
      setProcessing({ isProcessing: false, status: 'Error', progress: 0 });
    }
  };

  const handleFieldUpdate = (id: string, value: string) => {
    setExtractedFields(prev => prev.map(f => f.id === id ? { ...f, value } : f));
  };

  const clearSession = () => {
    if (window.confirm("Are you sure you want to end this session? All patient data and extracted fields will be permanently wiped from browser memory.")) {
      setPatientSources([]);
      setBlankForm(null);
      setExtractedFields([]);
      setProcessing({ isProcessing: false, status: 'Idle', progress: 0 });
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Header />
      
      <main className="flex-1 p-8 lg:p-12">
        <div className="max-w-[1600px] mx-auto grid grid-cols-1 lg:grid-cols-12 gap-10">
          
          {/* Left Column: Input Management */}
          <div className="lg:col-span-4 space-y-8">
            {/* HIPAA Disclaimer Section */}
            <section className="bg-blue-600 p-6 rounded-2xl shadow-lg shadow-blue-200 text-white overflow-hidden relative">
              <div className="relative z-10">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center backdrop-blur-md">
                    <i className="fa-solid fa-shield-medical text-white text-xl"></i>
                  </div>
                  <h2 className="font-bold text-lg">HIPAA Compliance Notice</h2>
                </div>
                <p className="text-sm text-blue-50 leading-relaxed">
                  MediFill AI operates as a <strong>Zero-Persistence</strong> environment. 
                  Clinical data is processed in browser memory and discarded immediately upon session termination. 
                  No patient PHI is stored on our servers.
                </p>
                <div className="mt-4 flex gap-2">
                  <span className="text-[10px] bg-blue-500/50 px-2 py-1 rounded font-bold uppercase tracking-wider">End-to-End Encryption</span>
                  <span className="text-[10px] bg-blue-500/50 px-2 py-1 rounded font-bold uppercase tracking-wider">Local Processing</span>
                </div>
              </div>
              <i className="fa-solid fa-file-shield absolute -bottom-4 -right-4 text-white/10 text-8xl transform -rotate-12"></i>
            </section>

            <section className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
              <h2 className="font-bold text-slate-800 mb-6 flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <i className="fa-solid fa-file-import text-blue-600"></i>
                  Data Acquisition
                </span>
                <button 
                  onClick={clearSession}
                  className="text-xs font-bold text-red-500 hover:text-red-700 transition-colors flex items-center gap-1 group"
                >
                  <i className="fa-solid fa-trash-can group-hover:shake"></i>
                  Wipe Session
                </button>
              </h2>
              
              <div className="space-y-6">
                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase mb-2 block">1. Patient Records</label>
                  <FileUploader 
                    title="Upload Patient Data"
                    description="Upload clinical notes (txt), CSV logs, or photos of ID cards"
                    icon="fa-solid fa-cloud-arrow-up"
                    accept=".txt,.csv,.jpg,.jpeg,.png,.pdf"
                    onFileSelect={handlePatientFile}
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase mb-2 block">2. Blank Medical Form</label>
                  {!blankForm ? (
                    <FileUploader 
                      title="Upload PDF Form"
                      description="Drag & drop the blank insurance or intake form"
                      icon="fa-solid fa-file-pdf"
                      accentColor="indigo-600"
                      accept=".pdf,.jpg,.png"
                      onFileSelect={handleBlankForm}
                    />
                  ) : (
                    <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-4 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-indigo-600 flex items-center justify-center text-white">
                          <i className="fa-solid fa-check"></i>
                        </div>
                        <div>
                          <p className="text-sm font-bold text-indigo-900 truncate max-w-[150px]">{blankForm.name}</p>
                          <p className="text-[10px] text-indigo-600 font-bold uppercase">Form Loaded</p>
                        </div>
                      </div>
                      <button 
                        onClick={() => setBlankForm(null)}
                        className="text-indigo-400 hover:text-indigo-800 transition-colors"
                      >
                        <i className="fa-solid fa-rotate"></i>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </section>

            <section className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
              <PatientProfile 
                sources={patientSources} 
                onRemoveSource={removeSource} 
              />
              
              <div className="mt-8">
                <button 
                  onClick={runAutoFill}
                  disabled={processing.isProcessing || patientSources.length === 0 || !blankForm}
                  className={`w-full py-4 rounded-xl font-bold flex items-center justify-center gap-2 shadow-lg shadow-blue-200 transition-all
                    ${processing.isProcessing || patientSources.length === 0 || !blankForm
                      ? 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none'
                      : 'bg-blue-600 text-white hover:bg-blue-700 hover:scale-[1.02] active:scale-95'
                    }`}
                >
                  {processing.isProcessing ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      <span>Mapping Data...</span>
                    </>
                  ) : (
                    <>
                      <i className="fa-solid fa-wand-magic-sparkles"></i>
                      <span>Auto-Fill Form</span>
                    </>
                  )}
                </button>
                
                {processing.isProcessing && (
                  <div className="mt-4 space-y-2">
                    <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-blue-600 transition-all duration-500 ease-out"
                        style={{ width: `${processing.progress}%` }}
                      ></div>
                    </div>
                    <p className="text-[10px] text-center text-slate-400 font-bold uppercase tracking-widest">
                      {processing.status}
                    </p>
                  </div>
                )}
              </div>
            </section>
          </div>

          {/* Right Column: Comparison & Edit View */}
          <div className="lg:col-span-8 flex flex-col h-[calc(100vh-160px)]">
             <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-6 h-full">
                
                {/* Visual Source Preview */}
                <div className="flex flex-col h-full space-y-4">
                  <div className="bg-slate-800 text-white px-5 py-3 rounded-t-xl flex items-center gap-2">
                    <i className="fa-solid fa-eye text-sm"></i>
                    <h3 className="text-sm font-bold">Source Context</h3>
                  </div>
                  <div className="flex-1 bg-slate-200 rounded-b-xl overflow-hidden relative group">
                    {patientSources.length > 0 ? (
                      <div className="h-full w-full overflow-y-auto p-4 bg-slate-900 custom-scrollbar">
                         {patientSources.map(s => (
                           <div key={s.id} className="mb-4 last:mb-0">
                              <p className="text-[10px] font-bold text-slate-500 uppercase mb-2">{s.name}</p>
                              {s.type === FileSourceType.IMAGE ? (
                                <img src={s.content} className="w-full rounded-lg border border-slate-700" alt={s.name} />
                              ) : (
                                <div className="p-4 bg-slate-800 border border-slate-700 rounded-lg text-slate-300 text-xs font-mono whitespace-pre-wrap">
                                  {s.content}
                                </div>
                              )}
                           </div>
                         ))}
                      </div>
                    ) : (
                      <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-400">
                        <i className="fa-solid fa-layer-group text-4xl mb-3 opacity-20"></i>
                        <p className="text-xs italic">Awaiting source upload...</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Extracted Form Editor */}
                <FormEditor 
                  fields={extractedFields} 
                  onFieldChange={handleFieldUpdate}
                  isProcessing={processing.isProcessing}
                />
             </div>
          </div>
          
        </div>
      </main>
      
      <footer className="py-6 px-12 border-t border-slate-200 text-slate-400 text-xs flex justify-between">
        <p>© 2024 MediFill AI. Powered by Gemini 2.0. HIPAA Compliant Environment.</p>
        <div className="flex gap-4">
          <span className="flex items-center gap-1"><i className="fa-solid fa-shield-halved"></i> 256-bit AES</span>
          <span className="flex items-center gap-1"><i className="fa-solid fa-server"></i> US-East-1</span>
        </div>
      </footer>
    </div>
  );
};

export default App;
