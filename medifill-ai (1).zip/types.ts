
export enum FileSourceType {
  IMAGE = 'image',
  TEXT = 'text',
  PDF = 'pdf',
  CSV = 'csv'
}

export interface PatientSource {
  id: string;
  name: string;
  type: FileSourceType;
  content: string; // Base64 for images/PDFs, raw text for notes
  mimeType: string;
}

export interface FormField {
  id: string;
  label: string;
  value: string;
  type: 'text' | 'checkbox' | 'date' | 'select';
  category: string;
}

export interface ProcessingState {
  isProcessing: boolean;
  status: string;
  progress: number;
}
