
import React, { useState, useRef, useEffect, useCallback } from 'react';
import ReactDOM from 'react-dom/client';
import { GoogleGenAI, Type } from "@google/genai";
import * as pdfjsLib from 'https://esm.sh/pdfjs-dist@4.0.263/build/pdf.mjs';

// Configure PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://esm.sh/pdfjs-dist@4.0.263/build/pdf.worker.mjs';

// --- TYPES & INTERFACES ---

interface PatientSource {
  id: string;
  name: string;
  type: 'image' | 'text' | 'csv';
  data: string; // Base64 or plain text
  status: 'pending' | 'processed';
}

interface FormField {
  id: string;
  label: string;
  value: string;
  type: 'text' | 'checkbox' | 'date' | 'select';
  section?: string;
}

interface MedicalForm {
  id: string;
  name: string;
  image: string; // Base64 of the form preview (rendered PDF or original image)
  fields: FormField[];
}

interface ExtractionState {
  isExtracting: boolean;
  progress: number;
  error?: string;
}

// --- SERVICES ---

const GEMINI_MODEL = 'gemini-3-flash-preview';

/**
 * Renders the first page of a PDF file to a Data URL image.
 */
const renderPdfToDataUrl = async (file: File): Promise<string> => {
  const arrayBuffer = await file.arrayBuffer();
  const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
  const pdf = await loadingTask.promise;
  const page = await pdf.getPage(1);
  
  const viewport = page.getViewport({ scale: 2.0 }); // High quality scale
  const canvas = document.createElement('canvas');
  const context = canvas.getContext('2d');
  canvas.height = viewport.height;
  canvas.width = viewport.width;
  
  await page.render({ canvasContext: context!, viewport }).promise;
  return canvas.toDataURL('image/jpeg', 0.85);
};

const extractPatientData = async (sources: PatientSource[]): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const parts: any[] = sources.map(source => {
    if (source.type === 'image') {
      return {
        inlineData: {
          mimeType: 'image/jpeg',
          data: source.data.split(',')[1] || source.data,
        },
      };
    } else {
      return { text: `Source (${source.name}):\n${source.data}` };
    }
  });

  parts.unshift({ text: "Please extract all relevant patient information (Full Name, DOB, Address, Insurance Details, Allergies, Medical History, etc.) from the following clinical sources. Consolidate them into a clear, professional medical summary for a doctor's intake assistant." });

  const response = await ai.models.generateContent({
    model: GEMINI_MODEL,
    contents: { parts },
  });

  return response.text || "No data extracted.";
};

const mapToForm = async (consolidatedData: string, formImageBase64: string): Promise<FormField[]> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    You are an expert medical data processing AI specialized in medical coding and clinical document correlation.
    
    I will provide:
    1. A summary of patient data.
    2. An image of a medical form.

    Your Task:
    1. Analyze the form image to identify all fillable data points (Labels, Checkboxes, Tables).
    2. Extract relevant data from the Patient Data Summary and match it precisely to the form's requirements.
    3. For checkboxes, return "true" if the patient data indicates a match (e.g., 'smoker' in records matches a 'Tobacco' checkbox), or "false".
    4. Return a structured JSON array of objects.

    Patient Data Summary:
    ${consolidatedData}
  `;

  const response = await ai.models.generateContent({
    model: GEMINI_MODEL,
    contents: {
      parts: [
        { text: prompt },
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: formImageBase64.split(',')[1] || formImageBase64,
          },
        },
      ],
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.STRING, description: "Unique identifier for the form field." },
            label: { type: Type.STRING, description: "Display label for the field." },
            value: { type: Type.STRING, description: "The extracted/mapped value for this field." },
            type: { type: Type.STRING, description: "Type: text or checkbox" },
            section: { type: Type.STRING, description: "Optional logical section of the form." },
          },
          required: ["id", "label", "value", "type"],
        },
      },
    },
  });

  try {
    return JSON.parse(response.text || "[]");
  } catch (e) {
    console.error("Failed to parse form mapping:", e);
    return [];
  }
};

// --- COMPONENTS ---

const Header: React.FC<{ onAutoFill: () => void; onReset: () => void; isExtracting: boolean; hasData: boolean }> = ({ 
  onAutoFill, onReset, isExtracting, hasData 
}) => (
  <header className="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-sm">
    <div className="container mx-auto px-4 h-16 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white font-bold shadow-lg shadow-blue-200">
          M
        </div>
        <div className="hidden sm:block">
          <h1 className="text-xl font-bold text-slate-900 tracking-tight leading-none">MediFill AI</h1>
          <p className="text-[10px] uppercase tracking-[0.2em] text-blue-500 font-bold mt-1">Clinical Intelligence</p>
        </div>
      </div>

      <div className="flex items-center gap-2 sm:gap-4">
        {hasData && !isExtracting && (
          <button 
            onClick={onReset}
            className="text-slate-400 hover:text-red-600 text-xs font-bold transition-all flex items-center gap-1.5 px-3 py-2 rounded-lg hover:bg-red-50"
            title="Securely clear session data"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
            </svg>
            <span className="hidden xs:inline">Secure Wipe</span>
          </button>
        )}
        
        <button 
          onClick={onAutoFill}
          disabled={isExtracting}
          className={`
            px-5 sm:px-8 py-2.5 rounded-full font-bold text-sm transition-all duration-300 flex items-center gap-2 shadow-xl
            ${isExtracting 
              ? 'bg-slate-100 text-slate-400 cursor-not-allowed shadow-none' 
              : 'bg-blue-600 text-white hover:bg-blue-700 active:scale-95 shadow-blue-200'
            }
          `}
        >
          {isExtracting ? (
            <>
              <svg className="animate-spin h-4 w-4 text-slate-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              AI Correlating...
            </>
          ) : (
            <>
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
              Auto-Fill Form
            </>
          )}
        </button>
      </div>
    </div>
  </header>
);

const SignaturePad: React.FC<{ onSave: (dataUrl: string) => void; onClear: () => void; savedSignature?: string }> = ({ 
  onSave, onClear, savedSignature 
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasSignature, setHasSignature] = useState(!!savedSignature);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    if (savedSignature) {
      const img = new Image();
      img.onload = () => ctx.drawImage(img, 0, 0, rect.width, rect.height);
      img.src = savedSignature;
    }
  }, [savedSignature]);

  const getPos = (e: any) => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    return { x: clientX - rect.left, y: clientY - rect.top };
  };

  const start = (e: any) => {
    const { x, y } = getPos(e);
    const ctx = canvasRef.current?.getContext('2d');
    if (ctx) { ctx.beginPath(); ctx.moveTo(x, y); setIsDrawing(true); }
  };
  const draw = (e: any) => {
    if (!isDrawing) return;
    const { x, y } = getPos(e);
    const ctx = canvasRef.current?.getContext('2d');
    if (ctx) { ctx.lineTo(x, y); ctx.stroke(); setHasSignature(true); }
  };
  const end = () => setIsDrawing(false);

  return (
    <div className="space-y-3">
      <div className="relative border-2 border-gray-200 rounded-xl bg-white shadow-inner cursor-crosshair overflow-hidden">
        <canvas ref={canvasRef} onMouseDown={start} onMouseMove={draw} onMouseUp={end} onTouchStart={start} onTouchMove={draw} onTouchEnd={end} className="w-full h-32 touch-none" />
        {!hasSignature && <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-20"><span className="text-sm font-bold uppercase tracking-widest text-slate-400">Digital Sign Required</span></div>}
      </div>
      <div className="flex gap-2">
        <button onClick={() => { 
          const ctx = canvasRef.current?.getContext('2d'); 
          ctx?.clearRect(0,0,1000,1000); setHasSignature(false); onClear(); 
        }} className="flex-1 py-2 text-[10px] font-bold uppercase bg-white border border-gray-200 rounded-lg text-slate-500 hover:bg-gray-50 transition-colors">Clear</button>
        <button onClick={() => hasSignature && onSave(canvasRef.current!.toDataURL())} disabled={!hasSignature} className={`flex-1 py-2 text-[10px] font-bold uppercase rounded-lg transition-all ${hasSignature ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-300'}`}>Verify Sign</button>
      </div>
    </div>
  );
};

// --- MAIN APP ---

const App: React.FC = () => {
  const [sources, setSources] = useState<PatientSource[]>([]);
  const [blankForm, setBlankForm] = useState<MedicalForm | null>(null);
  const [mappedFields, setMappedFields] = useState<FormField[]>([]);
  const [extractionState, setExtractionState] = useState<ExtractionState>({ isExtracting: false, progress: 0 });
  const [view, setView] = useState<'upload' | 'mapping'>('upload');
  const [signature, setSignature] = useState<string | undefined>();
  const [isRenderingPdf, setIsRenderingPdf] = useState(false);

  const handleReset = () => {
    if (window.confirm("Perform secure data wipe? All patient session data will be permanently cleared for HIPAA security.")) {
      setSources([]); setBlankForm(null); setMappedFields([]); setSignature(undefined);
      setExtractionState({ isExtracting: false, progress: 0 }); setView('upload');
    }
  };

  const handleAutoFill = async () => {
    if (sources.length === 0 || !blankForm) {
      alert("Error: Please provide at least one patient record and a clinical form.");
      return;
    }
    setExtractionState({ isExtracting: true, progress: 15 });
    setView('mapping');
    try {
      const summary = await extractPatientData(sources);
      setExtractionState(p => ({ ...p, progress: 50 }));
      const fields = await mapToForm(summary, blankForm.image);
      setMappedFields(fields);
      setExtractionState({ isExtracting: false, progress: 100 });
    } catch (e) {
      setExtractionState({ isExtracting: false, progress: 0, error: "AI Correlation Failure. Check network or API configuration." });
    }
  };

  return (
    <div className="min-h-screen flex flex-col selection:bg-blue-100">
      <Header onAutoFill={handleAutoFill} onReset={handleReset} isExtracting={extractionState.isExtracting} hasData={sources.length > 0 || !!blankForm} />

      <main className="flex-1 container mx-auto px-4 py-8">
        {/* Semantic Landmark for SEO */}
        <section aria-label="Privacy Disclaimer" className="mb-8 bg-blue-600 text-white p-5 rounded-2xl shadow-xl shadow-blue-200/50 flex flex-col sm:flex-row items-center gap-4 border border-blue-500">
          <div className="bg-blue-500/50 p-3 rounded-full shrink-0">
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
          </div>
          <div>
            <h2 className="text-lg font-bold">Secure HIPAA Session Active</h2>
            <p className="text-xs text-blue-100 mt-1 leading-relaxed max-w-2xl opacity-90">
              MediFill AI enforces strict volatile memory standards. Data is processed locally and via encrypted API streams only. No patient Identifiable Health Information (PHI) is persisted on our servers.
            </p>
          </div>
        </section>

        {view === 'upload' ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
            {/* Patient Profile Section */}
            <article className="bg-white rounded-3xl shadow-sm border border-gray-200 overflow-hidden flex flex-col">
              <div className="p-6 bg-gray-50/50 border-b border-gray-100 flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-bold text-slate-800 tracking-tight">Patient Records Vault</h2>
                  <p className="text-xs text-slate-400 font-medium">Upload Clinical Notes, ID Cards, or Data Logs</p>
                </div>
                <span className="bg-white px-3 py-1 rounded-full text-[10px] font-bold text-blue-500 border border-blue-100 uppercase tracking-widest">{sources.length} Items</span>
              </div>
              <div className="p-6 flex-1 flex flex-col">
                <div className="flex-1 space-y-3 mb-6">
                  {sources.length === 0 ? (
                    <div className="h-48 border-2 border-dashed border-gray-200 rounded-2xl flex flex-col items-center justify-center text-slate-300">
                      <svg className="w-10 h-10 mb-2 opacity-20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
                      <span className="text-xs font-bold uppercase tracking-tighter">Record Stream Empty</span>
                    </div>
                  ) : (
                    sources.map(s => (
                      <div key={s.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl border border-gray-100 animate-in fade-in zoom-in duration-300">
                        <div className="flex items-center gap-3 overflow-hidden">
                          <div className="p-2 bg-white rounded-lg shadow-sm shrink-0">
                            {s.type === 'image' ? <svg className="w-4 h-4 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg> : <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>}
                          </div>
                          <span className="text-sm font-semibold truncate text-slate-700">{s.name}</span>
                        </div>
                        <button onClick={() => setSources(prev => prev.filter(x => x.id !== s.id))} className="text-slate-300 hover:text-red-500"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg></button>
                      </div>
                    ))
                  )}
                </div>
                <label className="w-full py-4 bg-blue-600 text-white rounded-2xl font-bold flex items-center justify-center gap-2 cursor-pointer hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 active:scale-95">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 4v16m8-8H4" /></svg>
                  Ingest Patient File
                  <input type="file" multiple className="hidden" onChange={async (e) => {
                    const files = Array.from(e.target.files || []) as File[];
                    for (const f of files) {
                      if (f.type === 'application/pdf') {
                        setIsRenderingPdf(true);
                        const img = await renderPdfToDataUrl(f);
                        setSources(p => [...p, { id: Math.random().toString(36).slice(2), name: f.name, type: 'image', data: img, status: 'pending' }]);
                        setIsRenderingPdf(false);
                      } else {
                        const r = new FileReader();
                        r.onload = (ev) => setSources(p => [...p, { id: Math.random().toString(36).slice(2), name: f.name, type: f.type.includes('image') ? 'image' : 'text', data: ev.target?.result as string, status: 'pending' }]);
                        f.type.includes('image') ? r.readAsDataURL(f) : r.readAsText(f);
                      }
                    }
                  }} />
                </label>
              </div>
            </article>

            {/* Form Upload Section */}
            <article className="bg-white rounded-3xl shadow-sm border border-gray-200 overflow-hidden flex flex-col">
              <div className="p-6 bg-gray-50/50 border-b border-gray-100">
                <h2 className="text-lg font-bold text-slate-800 tracking-tight">Clinical Intake Forms</h2>
                <p className="text-xs text-slate-400 font-medium">Upload blank PDF/Images of Clinical Documents</p>
              </div>
              <div className="p-6 flex-1 flex flex-col items-center justify-center min-h-[300px]">
                {isRenderingPdf ? (
                  <div className="flex flex-col items-center gap-3">
                    <div className="w-10 h-10 border-4 border-blue-100 border-t-blue-500 rounded-full animate-spin"></div>
                    <span className="text-xs font-bold text-slate-400 animate-pulse">Rendering PDF Structure...</span>
                  </div>
                ) : (
                  <div onClick={() => (document.getElementById('form-in') as HTMLInputElement).click()} className={`w-full h-full min-h-[250px] border-2 border-dashed rounded-3xl flex flex-col items-center justify-center cursor-pointer transition-all ${blankForm ? 'border-blue-400 bg-blue-50/20' : 'border-gray-200 hover:border-blue-300 hover:bg-gray-50'}`}>
                    {blankForm ? (
                      <div className="text-center animate-in zoom-in duration-500 p-4">
                        <div className="relative inline-block group">
                           <img src={blankForm.image} className="w-48 h-auto max-h-[400px] object-contain rounded-xl shadow-2xl border border-white mb-4 transition-transform group-hover:scale-[1.02]" alt="Form preview" />
                           <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 rounded-xl transition-all"></div>
                        </div>
                        <p className="text-sm font-bold text-slate-800">{blankForm.name}</p>
                        <p className="text-[10px] text-slate-400 uppercase mt-1">Structure verified by PDF renderer</p>
                        <button className="text-[10px] font-bold text-blue-600 uppercase mt-3 tracking-widest bg-blue-50 px-3 py-1 rounded-full border border-blue-100 hover:bg-blue-100 transition-colors">Replace Document</button>
                      </div>
                    ) : (
                      <>
                        <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center text-slate-300 mb-4 shadow-inner">
                          <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
                        </div>
                        <p className="text-sm font-bold text-slate-700">Drop Clinical Template</p>
                        <p className="text-[10px] text-slate-400 mt-1 uppercase font-bold tracking-tighter">Native PDF Rendering • Image OCR</p>
                      </>
                    )}
                  </div>
                )}
                <input id="form-in" type="file" className="hidden" onChange={async (e) => {
                  const f = e.target.files?.[0]; if (!f) return;
                  if (f.type === 'application/pdf') {
                    setIsRenderingPdf(true);
                    try {
                      const img = await renderPdfToDataUrl(f);
                      setBlankForm({ id: '1', name: f.name, image: img, fields: [] });
                    } catch (err) {
                      console.error("PDF Rendering failed", err);
                      alert("Could not render PDF. Please upload an image version or check file integrity.");
                    }
                    setIsRenderingPdf(false);
                  } else {
                    const r = new FileReader(); r.onload = (ev) => setBlankForm({ id: '1', name: f.name, image: ev.target?.result as string, fields: [] });
                    r.readAsDataURL(f);
                  }
                }} />
              </div>
            </article>
          </div>
        ) : (
          /* Extraction View Section */
          <div className="animate-in fade-in zoom-in-95 duration-700">
            <div className="flex flex-col md:flex-row items-center justify-between mb-8 gap-4">
              <button onClick={() => setView('upload')} className="flex items-center gap-2 text-slate-500 hover:text-blue-600 font-bold transition-all"><svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg> Back to Intake</button>
              <div className="flex gap-3">
                <button onClick={() => {
                  const blob = new Blob([JSON.stringify({ fields: mappedFields, signature, timestamp: new Date() }, null, 2)], { type: 'application/json' });
                  const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = `MediFill_Export_${Date.now()}.json`; a.click();
                }} className="px-8 py-3 bg-slate-900 text-white rounded-full font-bold shadow-xl hover:bg-slate-800 transition-all flex items-center gap-2">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                  Export Signed Document
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              {/* Left Column: Data Sources */}
              <aside className="lg:col-span-4 space-y-4 max-h-[calc(100vh-350px)] overflow-y-auto custom-scrollbar pr-2">
                <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-400 mb-2 flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div> Reference Records</h3>
                {sources.map(s => (
                  <div key={s.id} className="bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm">
                    <div className="px-4 py-2 bg-gray-50 border-b border-gray-100 flex items-center justify-between font-bold text-[10px] text-slate-500">
                      <span>{s.name}</span>
                      <span className="bg-white px-2 py-0.5 rounded border border-gray-200">{s.type}</span>
                    </div>
                    <div className="p-4">
                      {s.type === 'image' ? <img src={s.data} className="w-full rounded-lg shadow-inner grayscale-[0.5]" /> : <pre className="text-[10px] font-mono whitespace-pre-wrap bg-gray-50 p-3 rounded-lg border border-gray-100 max-h-40 overflow-y-auto text-slate-600">{s.data}</pre>}
                    </div>
                  </div>
                ))}
              </aside>

              {/* Right Column: AI Filled Fields */}
              <section className="lg:col-span-8 bg-white border border-gray-200 rounded-3xl shadow-2xl shadow-slate-200 overflow-hidden flex flex-col max-h-[calc(100vh-350px)]">
                <div className="bg-blue-600 p-6 flex items-center justify-between">
                  <div><h3 className="text-white font-bold tracking-tight">Clinical Form Preview</h3><p className="text-[10px] text-blue-100 uppercase font-bold tracking-widest mt-1 opacity-80">AI Field Correlation Engine</p></div>
                  {extractionState.isExtracting && <div className="flex items-center gap-3"><div className="w-24 h-2 bg-blue-800 rounded-full overflow-hidden"><div className="h-full bg-white transition-all duration-500" style={{ width: `${extractionState.progress}%` }}></div></div><span className="text-[10px] font-bold text-white font-mono">{extractionState.progress}%</span></div>}
                </div>
                <div className="flex-1 overflow-y-auto p-8 custom-scrollbar space-y-10">
                  {extractionState.isExtracting ? (
                    <div className="h-full flex flex-col items-center justify-center text-slate-300 gap-4">
                      <div className="w-16 h-16 border-4 border-slate-100 border-t-blue-500 rounded-full animate-spin"></div>
                      <p className="text-sm font-bold text-slate-400 animate-pulse">Analyzing multi-modal medical context...</p>
                    </div>
                  ) : mappedFields.length > 0 ? (
                    <div className="space-y-12">
                      {/* Visual Reference of the Document */}
                      <div className="border border-gray-200 rounded-2xl p-4 bg-gray-50/50 flex flex-col items-center">
                         <h4 className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-4 self-start">Document Visual Context</h4>
                         <img src={blankForm?.image} className="w-full max-w-[600px] h-auto object-contain rounded-lg shadow-lg border border-white" alt="Mapped Form Preview" />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                        {mappedFields.map(f => (
                          <div key={f.id} className="p-4 bg-gray-50 border border-gray-200 rounded-2xl shadow-sm hover:border-blue-300 transition-colors group">
                            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1 group-focus-within:text-blue-500">{f.label}</label>
                            {f.type === 'checkbox' ? (
                              <div className="flex items-center gap-3 py-2">
                                <input type="checkbox" checked={f.value === 'true'} onChange={e => setMappedFields(p => p.map(x => x.id === f.id ? { ...x, value: e.target.checked ? 'true' : 'false' } : x))} className="w-5 h-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500 cursor-pointer" />
                                <span className="text-xs font-semibold text-slate-600">Correlated in Records</span>
                              </div>
                            ) : (
                              <input type="text" value={f.value} onChange={e => setMappedFields(p => p.map(x => x.id === f.id ? { ...x, value: e.target.value } : x))} className="w-full bg-white border border-gray-200 rounded-xl px-4 py-2 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400 transition-all text-slate-800" />
                            )}
                          </div>
                        ))}
                      </div>

                      {/* Signature Section */}
                      <div className="mt-12 pt-12 border-t border-gray-100 max-w-md mx-auto">
                        <div className="flex items-center justify-between mb-6">
                          <div><h4 className="text-xs font-bold uppercase tracking-widest text-slate-800">Verification Signature</h4><p className="text-[10px] text-slate-400 font-medium">Clinician / Provider Authorization</p></div>
                          {signature && <span className="bg-green-50 text-green-600 border border-green-100 px-3 py-1 rounded-full text-[9px] font-bold uppercase">Digitally Verified</span>}
                        </div>
                        {signature ? (
                          <div className="relative group">
                            <div className="bg-white border-2 border-dashed border-gray-200 rounded-3xl p-6 flex flex-col items-center shadow-inner">
                              <img src={signature} alt="Sign" className="max-h-24 grayscale brightness-50" />
                              <div className="w-full border-t border-gray-100 mt-4 pt-4 text-center">
                                <p className="text-[9px] font-mono text-slate-400 uppercase tracking-widest">DIGITAL_CERT: {Math.random().toString(16).slice(2, 12).toUpperCase()}</p>
                              </div>
                            </div>
                            <button onClick={() => setSignature(undefined)} className="absolute -top-3 -right-3 bg-white border border-gray-200 p-2 rounded-full shadow-lg text-slate-400 hover:text-red-500 transition-colors"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" /></svg></button>
                          </div>
                        ) : <SignaturePad onSave={s => setSignature(s)} onClear={() => setSignature(undefined)} />}
                        <p className="mt-6 text-[10px] text-center text-slate-400 italic leading-relaxed">By providing an electronic signature, I acknowledge that the clinical data mapped above is a true and accurate reflection of the patient's record at the time of session creation.</p>
                      </div>
                    </div>
                  ) : (
                    <div className="h-full flex flex-col items-center justify-center text-slate-300 opacity-50">
                      <p className="text-sm font-bold uppercase tracking-widest">Awaiting Extraction Analysis</p>
                    </div>
                  )}
                </div>
              </section>
            </div>
          </div>
        )}
      </main>

      <footer className="bg-white border-t border-gray-200 py-10 mt-auto">
        <div className="container mx-auto px-4 text-center">
          <div className="flex flex-col items-center gap-4">
            <div className="flex items-center gap-3 text-slate-300">
               <svg className="w-5 h-5 opacity-40" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 4.925-3.467 9.49-8 10.944-4.533-1.454-8-6.019-8-10.944 0-.681.056-1.35.166-2.001zm8 1.455a1 1 0 00-1 1v4a1 1 0 102 0v-4a1 1 0 00-1-1zM10 14a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" /></svg>
               <span className="text-[10px] font-bold uppercase tracking-[0.3em]">HIPAA Secure Automation Infrastructure</span>
            </div>
            <p className="text-slate-500 text-sm font-medium">&copy; {new Date().getFullYear()} MediFill AI. Professional Healthcare Automation Solutions.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

// --- RENDER ---

const rootElement = document.getElementById('root');
if (rootElement) {
  ReactDOM.createRoot(rootElement).render(<React.StrictMode><App /></React.StrictMode>);
}
