
import { GoogleGenAI, Type } from "@google/genai";
import { PatientSource, FormField } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const extractPatientData = async (sources: PatientSource[]): Promise<string> => {
  const model = 'gemini-3-flash-preview';
  
  const parts = sources.map(source => {
    if (source.type === 'image') {
      return {
        inlineData: {
          mimeType: 'image/jpeg',
          data: source.data.split(',')[1] || source.data,
        },
      };
    } else {
      return { text: `Source (${source.name}):\n${source.data}` };
    }
  });

  parts.unshift({ text: "Please extract all relevant patient information (Full Name, DOB, Address, Insurance Details, Allergies, Medical History, etc.) from the following sources. Consolidate them into a clear summary." });

  const response = await ai.models.generateContent({
    model,
    contents: { parts },
  });

  return response.text || "No data extracted.";
};

export const mapToForm = async (consolidatedData: string, formImageBase64: string): Promise<FormField[]> => {
  const model = 'gemini-3-flash-preview';
  
  const prompt = `
    You are an expert medical data processing AI. 
    I will provide:
    1. A summary of patient data.
    2. An image of a medical form.

    Task: 
    1. Identify all fillable fields in the form (labels, checkboxes, tables).
    2. Map the relevant patient data to these fields.
    3. For checkboxes, return "true" if the condition matches the patient data, or "false".
    4. Return a structured list of field mappings.

    Patient Data Summary:
    ${consolidatedData}
  `;

  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        { text: prompt },
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: formImageBase64.split(',')[1] || formImageBase64,
          },
        },
      ],
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.STRING },
            label: { type: Type.STRING },
            value: { type: Type.STRING },
            type: { type: Type.STRING },
            section: { type: Type.STRING },
          },
          required: ["id", "label", "value", "type"],
        },
      },
    },
  });

  try {
    return JSON.parse(response.text || "[]");
  } catch (e) {
    console.error("Failed to parse form mapping:", e);
    return [];
  }
};
