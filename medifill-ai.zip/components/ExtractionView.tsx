
import React, { useState } from 'react';
import { PatientSource, MedicalForm, FormField, ExtractionState } from '../types';
import SignaturePad from './SignaturePad';

interface ExtractionViewProps {
  sources: PatientSource[];
  blankForm: MedicalForm | null;
  fields: FormField[];
  extractionState: ExtractionState;
  onUpdateField: (id: string, value: string) => void;
  onBack: () => void;
  onReset: () => void;
}

const ExtractionView: React.FC<ExtractionViewProps> = ({ 
  sources, 
  blankForm, 
  fields, 
  extractionState, 
  onUpdateField,
  onBack,
  onReset
}) => {
  const [signature, setSignature] = useState<string | undefined>();
  const [isSignModalOpen, setIsSignModalOpen] = useState(false);

  const handleDownload = () => {
    const exportData = {
      fields,
      signature: signature || null,
      timestamp: new Date().toISOString(),
      formName: blankForm?.name
    };
    
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(exportData, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", `MediFill_${blankForm?.name || 'Form'}_Filled.json`);
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between mb-4">
        <button 
          onClick={onBack}
          className="flex items-center gap-2 text-slate-500 hover:text-blue-600 transition-colors font-semibold"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
          </svg>
          Return to Uploads
        </button>

        <div className="flex gap-3">
          <button 
            disabled={extractionState.isExtracting}
            onClick={handleDownload}
            className={`
              px-8 py-2.5 rounded-full font-bold flex items-center gap-2 shadow-lg transition-all duration-300
              ${extractionState.isExtracting 
                ? 'bg-gray-200 text-gray-400 cursor-not-allowed' 
                : 'bg-blue-600 text-white hover:bg-blue-700 active:scale-95 shadow-blue-200'}
            `}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
            Export Signed Form
          </button>
          
          <button 
            disabled={extractionState.isExtracting}
            onClick={onReset}
            className={`
              px-6 py-2.5 rounded-full font-bold flex items-center gap-2 shadow-sm transition-all border-2
              ${extractionState.isExtracting 
                ? 'bg-gray-50 text-gray-300 border-gray-100' 
                : 'bg-white text-red-500 border-red-100 hover:bg-red-50 hover:border-red-200'}
            `}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m0 0v3m0-3h3m-3 0H9m12 1a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            Secure Session Wipe
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Original Sources */}
        <div className="lg:col-span-4 h-[calc(100vh-280px)] overflow-y-auto pr-2 space-y-4">
          <h3 className="text-xs uppercase tracking-[0.15em] font-bold text-slate-400 mb-2 flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-blue-400"></div>
            Original Data Sources
          </h3>
          {sources.map(source => (
            <div key={source.id} className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
              <div className="px-4 py-2 bg-gray-50 border-b border-gray-100 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-600 truncate">{source.name}</span>
                <span className="text-[10px] bg-white border border-gray-200 px-2 py-0.5 rounded-full text-slate-500 font-mono">{source.type}</span>
              </div>
              <div className="p-4">
                {source.type === 'image' ? (
                  <img src={source.data} alt={source.name} className="w-full rounded-lg border border-gray-100 shadow-inner" />
                ) : (
                  <pre className="text-[11px] font-mono text-slate-700 whitespace-pre-wrap bg-gray-50 p-3 rounded-lg border border-gray-100 max-h-48 overflow-y-auto shadow-inner">
                    {source.data}
                  </pre>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Right: Live Preview & Mapping */}
        <div className="lg:col-span-8 bg-white border border-gray-200 rounded-2xl shadow-xl overflow-hidden h-[calc(100vh-320px)] flex flex-col">
          <div className="px-6 py-5 bg-blue-600 text-white flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm uppercase tracking-wider">Form Intelligence Preview</h3>
              <p className="text-[11px] text-blue-100 mt-0.5">Automated Field Correlator Active</p>
            </div>
            {extractionState.isExtracting && (
              <div className="flex items-center gap-3">
                <div className="w-24 h-2 bg-blue-800/50 rounded-full overflow-hidden border border-blue-400/20">
                  <div className="h-full bg-white transition-all duration-500" style={{ width: `${extractionState.progress}%` }}></div>
                </div>
                <span className="text-[10px] font-bold font-mono text-white">{extractionState.progress}%</span>
              </div>
            )}
          </div>

          <div className="flex-1 overflow-y-auto p-6 space-y-8 bg-gray-50/30">
            {extractionState.isExtracting ? (
              <div className="flex flex-col items-center justify-center h-full text-slate-400 py-12">
                <div className="relative mb-6">
                  <div className="w-24 h-24 border-4 border-gray-100 border-t-blue-500 rounded-full animate-spin"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <svg className="w-10 h-10 text-blue-100" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.673.337a4 4 0 01-2.586.343l-1.1-.11a2 2 0 01-1.583-1.228L5.414 11m14.014 4.414a2 2 0 01-1.414 1.414L5.414 16.828a2 2 0 01-1.414-1.414l1.414-1.414a2 2 0 011.414-1.414l12.586 1.414a2 2 0 011.414 1.414z" />
                    </svg>
                  </div>
                </div>
                <h4 className="text-slate-900 font-bold mb-1">Mapping Intelligence Active</h4>
                <p className="text-sm max-w-xs text-center text-slate-500">Gemini is correlating patient data points with clinical requirements...</p>
              </div>
            ) : fields.length > 0 ? (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {fields.map(field => (
                    <div key={field.id} className="space-y-1 bg-white p-3 rounded-xl border border-gray-200 shadow-sm focus-within:border-blue-300 transition-colors">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{field.label}</label>
                      {field.type === 'checkbox' ? (
                        <div className="flex items-center gap-3 py-1">
                          <input 
                            type="checkbox" 
                            checked={field.value === 'true'} 
                            onChange={(e) => onUpdateField(field.id, e.target.checked ? 'true' : 'false')}
                            className="w-5 h-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500 transition-all cursor-pointer"
                          />
                          <span className="text-xs font-semibold text-slate-600">Matched in records</span>
                        </div>
                      ) : (
                        <input 
                          type="text" 
                          value={field.value} 
                          onChange={(e) => onUpdateField(field.id, e.target.value)}
                          className="w-full bg-gray-50/50 border border-gray-100 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:border-blue-400 transition-all font-medium text-slate-800"
                          placeholder="--"
                        />
                      )}
                    </div>
                  ))}
                </div>

                {/* Digital Signature Section */}
                <div className="mt-8 border-t border-gray-200 pt-8">
                  <div className="max-w-md mx-auto">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-xs font-bold uppercase tracking-widest text-slate-500 flex items-center gap-2">
                        <svg className="w-4 h-4 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                        </svg>
                        Physician / Patient Authorization
                      </h4>
                      {signature && (
                        <span className="text-[10px] bg-green-50 text-green-600 px-2 py-0.5 rounded-full font-bold border border-green-100">
                          Verified
                        </span>
                      )}
                    </div>
                    
                    {signature ? (
                      <div className="relative group">
                        <div className="bg-white border-2 border-dashed border-gray-200 rounded-2xl p-4 flex flex-col items-center shadow-inner">
                          <img src={signature} alt="Digital Signature" className="max-h-24 w-auto grayscale" />
                          <div className="mt-2 w-full border-t border-gray-100 pt-2 text-center">
                            <p className="text-[10px] text-slate-400 font-mono">DIGITAL-ID: {Math.random().toString(16).slice(2, 10).toUpperCase()}</p>
                          </div>
                        </div>
                        <button 
                          onClick={() => setSignature(undefined)}
                          className="absolute -top-2 -right-2 bg-white border border-gray-200 text-slate-400 hover:text-red-500 p-1.5 rounded-full shadow-md transition-colors"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                          </svg>
                        </button>
                      </div>
                    ) : (
                      <div className="bg-gray-100 rounded-2xl p-6 border border-gray-200">
                        <SignaturePad 
                          onSave={(data) => setSignature(data)} 
                          onClear={() => setSignature(undefined)} 
                        />
                      </div>
                    )}
                    <p className="mt-4 text-[10px] text-center text-slate-400 leading-relaxed italic">
                      By signing above, I certify that the information provided is true and accurate to the best of my knowledge. This e-signature is legally binding as per clinical automation standards.
                    </p>
                  </div>
                </div>
              </>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-slate-400 py-12">
                 <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                   <svg className="w-6 h-6 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" />
                   </svg>
                 </div>
                 <p className="text-sm font-semibold text-slate-400">Awaiting Extraction Trigger</p>
                 <p className="text-xs mt-1 text-slate-300 uppercase tracking-tighter">Correlator engine ready</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExtractionView;
