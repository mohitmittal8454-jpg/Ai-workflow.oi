
import React, { useRef } from 'react';
import { MedicalForm } from '../types';

interface FormUploadSectionProps {
  blankForm: MedicalForm | null;
  onSetForm: (form: MedicalForm) => void;
}

const FormUploadSection: React.FC<FormUploadSectionProps> = ({ blankForm, onSetForm }) => {
  const formInputRef = useRef<HTMLInputElement>(null);

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      onSetForm({
        id: 'form-1',
        name: file.name,
        image: result,
        fields: []
      });
    };
    reader.readAsDataURL(file);
  };

  return (
    <section className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
      <div className="p-6 border-b border-gray-100 bg-gray-50/50">
        <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
          <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
          </svg>
          Form Upload Zone
        </h2>
        <p className="text-sm text-slate-500 mt-1">Upload blank insurance claims or medical intake forms.</p>
      </div>

      <div className="p-6">
        <div 
          onClick={() => formInputRef.current?.click()}
          className={`
            border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center cursor-pointer transition-all duration-300
            ${blankForm ? 'border-blue-200 bg-blue-50/20' : 'border-gray-200 hover:border-blue-400 hover:bg-gray-50'}
          `}
        >
          {blankForm ? (
            <div className="flex flex-col items-center">
              <div className="relative">
                <img src={blankForm.image} alt="Form Preview" className="w-32 h-40 object-cover rounded-lg shadow-md border border-gray-200" />
                <div className="absolute -top-2 -right-2 bg-blue-600 text-white p-1 rounded-full shadow-lg">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                </div>
              </div>
              <p className="mt-4 text-sm font-bold text-slate-700">{blankForm.name}</p>
              <button className="mt-2 text-xs text-blue-600 font-semibold hover:underline uppercase tracking-wider">Replace Document</button>
            </div>
          ) : (
            <>
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center text-gray-400 mb-4 group-hover:scale-110 transition-transform shadow-inner">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                </svg>
              </div>
              <p className="text-sm font-bold text-slate-700">Click or Drag PDF/Image</p>
              <p className="text-xs text-slate-400 mt-1 uppercase tracking-tighter">Supported: PDF, JPEG, PNG</p>
            </>
          )}
        </div>
        <input 
          type="file" 
          ref={formInputRef} 
          className="hidden" 
          onChange={handleFormChange}
          accept="image/*,.pdf"
        />
      </div>
    </section>
  );
};

export default FormUploadSection;
