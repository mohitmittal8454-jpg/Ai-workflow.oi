
import React from 'react';

interface HeaderProps {
  onAutoFill: () => void;
  onReset: () => void;
  isExtracting: boolean;
  hasData: boolean;
}

const Header: React.FC<HeaderProps> = ({ onAutoFill, onReset, isExtracting, hasData }) => {
  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold shadow-lg shadow-blue-200">
            M
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">MediFill AI</h1>
            <p className="text-[10px] uppercase tracking-widest text-slate-400 font-semibold -mt-1">Clinical Automation</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {hasData && !isExtracting && (
            <button 
              onClick={onReset}
              className="text-slate-500 hover:text-red-600 text-sm font-semibold transition-colors flex items-center gap-1.5 px-3 py-2 rounded-lg hover:bg-red-50"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
              </svg>
              Secure Wipe
            </button>
          )}
          
          <button 
            onClick={onAutoFill}
            disabled={isExtracting}
            className={`
              px-6 py-2.5 rounded-full font-medium transition-all duration-200 flex items-center gap-2 shadow-md
              ${isExtracting 
                ? 'bg-slate-100 text-slate-400 cursor-not-allowed' 
                : 'bg-blue-600 text-white hover:bg-blue-700 active:scale-95 shadow-blue-200'
              }
            `}
          >
            {isExtracting ? (
              <>
                <svg className="animate-spin h-4 w-4 text-slate-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Processing...
              </>
            ) : (
              <>
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
                Auto-Fill Form
              </>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
