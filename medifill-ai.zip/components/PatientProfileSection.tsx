
import React, { useRef } from 'react';
import { PatientSource } from '../types';

interface PatientProfileSectionProps {
  sources: PatientSource[];
  onAddSource: (source: PatientSource) => void;
  onRemoveSource: (id: string) => void;
}

const PatientProfileSection: React.FC<PatientProfileSectionProps> = ({ sources, onAddSource, onRemoveSource }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const reader = new FileReader();
      
      reader.onload = (event) => {
        const result = event.target?.result as string;
        const type: PatientSource['type'] = file.type.startsWith('image') ? 'image' : (file.name.endsWith('.csv') ? 'csv' : 'text');
        
        onAddSource({
          id: Math.random().toString(36).substr(2, 9),
          name: file.name,
          type,
          data: result,
          status: 'pending'
        });
      };

      if (file.type.startsWith('image')) {
        reader.readAsDataURL(file);
      } else {
        reader.readAsText(file);
      }
    }
    
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <section className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
      <div className="p-6 border-b border-gray-100 bg-gray-50/50">
        <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
          <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
          </svg>
          Patient Profile Management
        </h2>
        <p className="text-sm text-slate-500 mt-1">Upload ID cards, clinical notes, or patient data files.</p>
      </div>

      <div className="p-6">
        <div className="grid grid-cols-1 gap-4 mb-6">
          {sources.length === 0 ? (
            <div className="border-2 border-dashed border-gray-200 rounded-xl p-12 flex flex-col items-center justify-center text-slate-400 bg-gray-50/30">
              <svg className="w-12 h-12 mb-3 opacity-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              <p className="text-xs font-bold uppercase tracking-widest opacity-60">Session vault empty</p>
            </div>
          ) : (
            sources.map(source => (
              <div key={source.id} className="flex items-center justify-between p-3 bg-white border border-gray-100 rounded-xl hover:border-blue-200 transition-all shadow-sm hover:shadow-md">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${source.type === 'image' ? 'bg-blue-50 text-blue-600' : 'bg-slate-50 text-slate-600'} shadow-sm`}>
                    {source.type === 'image' ? (
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                      </svg>
                    ) : (
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                      </svg>
                    )}
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-slate-700 truncate max-w-[200px]">{source.name}</h4>
                    <span className="text-[10px] uppercase font-bold text-slate-400 tracking-tighter">{source.type} detected</span>
                  </div>
                </div>
                <button 
                  onClick={() => onRemoveSource(source.id)}
                  className="text-gray-300 hover:text-red-500 transition-colors p-1"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                </button>
              </div>
            ))
          )}
        </div>

        <button 
          onClick={() => fileInputRef.current?.click()}
          className="w-full py-3.5 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-200 active:scale-[0.98]"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" />
          </svg>
          Add Patient Source
        </button>
        <input 
          type="file" 
          multiple 
          ref={fileInputRef} 
          className="hidden" 
          onChange={handleFileChange}
          accept="image/*,.csv,.txt,.pdf"
        />
      </div>
    </section>
  );
};

export default PatientProfileSection;
