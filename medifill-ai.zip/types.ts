
export interface PatientSource {
  id: string;
  name: string;
  type: 'image' | 'text' | 'csv';
  data: string; // Base64 or plain text
  status: 'pending' | 'processed';
}

export interface FormField {
  id: string;
  label: string;
  value: string;
  type: 'text' | 'checkbox' | 'date' | 'select';
  section?: string;
}

export interface MedicalForm {
  id: string;
  name: string;
  image: string; // Base64 of the form preview
  fields: FormField[];
}

export interface ExtractionState {
  isExtracting: boolean;
  progress: number;
  error?: string;
}
