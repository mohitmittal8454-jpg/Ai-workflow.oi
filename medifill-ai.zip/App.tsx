
import React, { useState, useCallback } from 'react';
import Header from './components/Header';
import PatientProfileSection from './components/PatientProfileSection';
import FormUploadSection from './components/FormUploadSection';
import ExtractionView from './components/ExtractionView';
import { PatientSource, MedicalForm, FormField, ExtractionState } from './types';
import { extractPatientData, mapToForm } from './services/geminiService';

const App: React.FC = () => {
  const [sources, setSources] = useState<PatientSource[]>([]);
  const [blankForm, setBlankForm] = useState<MedicalForm | null>(null);
  const [mappedFields, setMappedFields] = useState<FormField[]>([]);
  const [extractionState, setExtractionState] = useState<ExtractionState>({
    isExtracting: false,
    progress: 0,
  });
  const [view, setView] = useState<'upload' | 'mapping'>('upload');

  const handleAddSource = (source: PatientSource) => {
    setSources(prev => [...prev, source]);
  };

  const handleRemoveSource = (id: string) => {
    setSources(prev => prev.filter(s => s.id !== id));
  };

  const handleSetForm = (form: MedicalForm) => {
    setBlankForm(form);
  };

  const handleReset = () => {
    if (window.confirm("Are you sure you want to clear all patient data? This session will be wiped for HIPAA security.")) {
      setSources([]);
      setBlankForm(null);
      setMappedFields([]);
      setExtractionState({ isExtracting: false, progress: 0 });
      setView('upload');
    }
  };

  const handleAutoFill = async () => {
    if (sources.length === 0 || !blankForm) {
      alert("Please upload at least one patient source and a blank form.");
      return;
    }

    setExtractionState({ isExtracting: true, progress: 10 });
    setView('mapping');

    try {
      setExtractionState(prev => ({ ...prev, progress: 30 }));
      const consolidatedData = await extractPatientData(sources);
      
      setExtractionState(prev => ({ ...prev, progress: 60 }));
      const fields = await mapToForm(consolidatedData, blankForm.image);
      
      setMappedFields(fields);
      setExtractionState({ isExtracting: false, progress: 100 });
    } catch (error) {
      console.error(error);
      setExtractionState({ isExtracting: false, progress: 0, error: "AI Processing Failed. Please try again." });
    }
  };

  const handleUpdateField = (id: string, newValue: string) => {
    setMappedFields(prev => prev.map(f => f.id === id ? { ...f, value: newValue } : f));
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-100/50">
      <Header onAutoFill={handleAutoFill} onReset={handleReset} isExtracting={extractionState.isExtracting} hasData={sources.length > 0 || !!blankForm} />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="mb-6 bg-blue-50 border-l-4 border-blue-600 p-4 rounded-r-lg flex items-start gap-3 shadow-sm">
          <svg className="w-5 h-5 text-blue-600 mt-0.5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
          </svg>
          <div>
            <h4 className="text-sm font-bold text-blue-900">HIPAA Protected Environment</h4>
            <p className="text-xs text-blue-700 leading-relaxed">
              Active session data is processed in-memory. MediFill AI utilizes end-to-end encryption for all Gemini API interactions. Ensure you use "Secure Wipe" to clear session artifacts.
            </p>
          </div>
        </div>

        {extractionState.error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 text-red-700 rounded-lg flex items-center justify-between shadow-sm">
            <span>{extractionState.error}</span>
            <button onClick={() => setExtractionState(prev => ({ ...prev, error: undefined }))} className="font-bold">&times;</button>
          </div>
        )}

        {view === 'upload' ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <PatientProfileSection 
              sources={sources} 
              onAddSource={handleAddSource} 
              onRemoveSource={handleRemoveSource} 
            />
            <FormUploadSection 
              blankForm={blankForm} 
              onSetForm={handleSetForm} 
            />
          </div>
        ) : (
          <ExtractionView 
            sources={sources}
            blankForm={blankForm}
            fields={mappedFields}
            extractionState={extractionState}
            onUpdateField={handleUpdateField}
            onBack={() => setView('upload')}
            onReset={handleReset}
          />
        )}
      </main>
      
      <footer className="bg-white border-t border-gray-200 py-8 text-center">
        <div className="container mx-auto px-4">
          <div className="flex flex-col items-center gap-3">
            <div className="flex items-center gap-2 text-slate-400">
               <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 4.925-3.467 9.49-8 10.944-4.533-1.454-8-6.019-8-10.944 0-.681.056-1.35.166-2.001zm8 1.455a1 1 0 00-1 1v4a1 1 0 102 0v-4a1 1 0 00-1-1zM10 14a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
              </svg>
              <span className="text-[11px] font-bold uppercase tracking-[0.2em]">Clinical Security Standard - MediFill v2.0</span>
            </div>
            <p className="text-slate-500 text-sm font-medium">
              &copy; {new Date().getFullYear()} MediFill AI. Professional Intelligent Health Automation.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
